
export const modernPageImage2: string = "/assets/images/modernPageImages/img-2.svg";
export const modernPageImage3: string = "/assets/images/modernPageImages/img-3.svg";
export const modernPageImage4: string = "/assets/images/modernPageImages/img-4.png";
export const aaluTikki: string = "/assets/images/productImages/aaluTikki.jpeg"
export const chickenMomos: string = "/assets/images/productImages/Chicken_Momos.jpg"

