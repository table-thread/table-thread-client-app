import React, { useState, useEffect } from 'react';

import Index from './product/index';

const Login = () => {


  return (
    <div className='p-0'>
      <Index />
    </div>
  );
}

export default Login;