import React from 'react';

const Subscription = () => {
  return (
      <div> this is Subscription </div>
  )
}

export default Subscription;
